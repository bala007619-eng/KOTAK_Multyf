# Multyfi Kotak Approval — Android source prototype

This is a notification capture and manual review prototype. It does not place, modify, or cancel orders. The Approve button records `APPROVED — NOT SENT` and attempts to open the installed Kotak Neo app; Reject records `REJECTED`. Opening Kotak Neo does not prefill or submit an order.

## Build
Open this folder in Android Studio, sync Gradle, install Android SDK 35 if prompted, then choose Build > Build APK(s). Install the resulting debug APK on your Android phone.

## Setup
1. Launch the app.
2. Select Multyfi in the app list and tap Save selected app.
3. Open notification access settings and enable access for this app.
4. Return to the app. Incoming notifications from the selected app will be captured and shown in the local list.
5. Approve records your local decision and attempts to open Kotak Neo. Reject records your local decision.

## Important limitations
- Notification parsing depends on the text that Multyfi actually places in Android notifications. The parser recognizes common labels; compare the captured raw notification with the displayed fields.
- This prototype has no Kotak API integration and does not send any order.
- Kotak Neo order APIs require a whitelisted static IP and a session created from that same IP under current requirements. A mobile-only app should not contain API secrets or attempt to bypass those controls. A compliant backend may be required for actual order submission.
- Never share API tokens, TOTP, MPIN, or session credentials.
