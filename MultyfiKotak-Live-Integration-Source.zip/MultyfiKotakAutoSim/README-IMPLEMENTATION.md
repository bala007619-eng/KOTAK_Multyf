# Multyfi → Kotak: simulation-first starter

Contains Android notification-monitor source plus a separate Oracle-hostable FastAPI simulation gateway.

**Safety status:** live order placement is intentionally absent and disabled. The backend only records simulated alerts. The supplied app is a source project, not a compiled APK. Build with GitHub Actions or Android Studio.

## Backend
See `oracle-backend/README.md`. Start locally first. For Oracle, use a VM with a reserved static public IP, firewall, TLS reverse proxy, secret management, monitoring, and backups. Verify current Oracle free-tier availability and static-IP charges in the OCI console.

## Before live integration
1. Obtain Kotak Neo API access and read the current official API documentation.
2. Confirm static-IP whitelisting and account/session requirements.
3. Implement and independently test instrument-master resolution, margin checks, F&O lot-size/tick validation, order state reconciliation, and realized/unrealized P&L daily loss enforcement.
4. Add broker adapter only after verifying exact API version, authentication and payload schema.
5. Keep live mode behind an explicit server-side deployment gate and test with broker-supported sandbox/paper facilities where available.

Never commit credentials, session tokens, OTP seeds, or private keys.
