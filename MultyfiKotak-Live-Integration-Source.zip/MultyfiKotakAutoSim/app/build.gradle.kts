plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.multyfikotakapproval"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.multyfikotakapproval"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "2.1"
    }
}
