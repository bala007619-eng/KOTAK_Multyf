# Oracle simulation gateway

This is a simulation-only starter. It has no Kotak credentials, broker SDK, order URL, or live order-submission code. `TRADING_MODE` must remain `simulation`; any other value prevents startup.

## Local run

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
export API_KEY="$(python3 -c 'import secrets; print(secrets.token_urlsafe(32))')"
export TRADING_MODE=simulation
uvicorn app:app --host 127.0.0.1 --port 8080
```

Use `/docs` locally. Set `x-api-key` on `/alerts`, `/alerts` GET, `/status`, and `/kill-switch`. Do not expose port 8080 directly to the internet; deploy behind TLS reverse proxy and firewall. Use a durable database and backups before any real use.

## Alert schema

`alert_id`, `raw`, `symbol`, `side` (`BUY`/`SELL`), `segment` (`EQUITY`/`FUTURES`/`OPTIONS`), `exchange` (`NSE`/`NFO`), `price`, `quantity`, optional `stop_loss`, optional `target`, `product` (`MIS`). This generic normalized schema is not a parser for every Multyfi notification layout. Confirm the alert source and instrument master before expanding it.

## Risk behavior

Default capital ₹20,000; max order value ₹20,000; daily loss setting ₹1,000 is exposed in status for the next risk-engine phase. This prototype does not calculate realized/unrealized P&L, margin, exchange lot sizes, or enforce the daily loss cap yet. It is not suitable for live trading. Missing stop-loss is accepted but flagged. No live orders can be sent.
