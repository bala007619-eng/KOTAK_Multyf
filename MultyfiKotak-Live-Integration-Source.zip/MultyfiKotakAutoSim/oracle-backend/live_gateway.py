"""Kotak Neo live-order adapter. Live mode is deliberately fail-closed."""
import os
from neo_api_client import NeoAPI

def client_from_env():
    required = ["NEO_CONSUMER_KEY", "NEO_MOBILE_NUMBER", "NEO_UCC", "NEO_MPIN"]
    missing = [k for k in required if not os.getenv(k)]
    if missing:
        raise RuntimeError("Missing broker configuration: " + ", ".join(missing))
    client = NeoAPI(consumer_key=os.environ["NEO_CONSUMER_KEY"], environment="prod")
    return client

def place_live_order(alert):
    # Require a fresh TOTP supplied out-of-band for each session; never store it.
    totp = os.getenv("NEO_TOTP_CURRENT")
    if not totp or len(totp) != 6 or not totp.isdigit():
        raise RuntimeError("Set a current 6-digit TOTP securely before opening a broker session")
    c = client_from_env()
    c.totp_login(mobile_number=os.environ["NEO_MOBILE_NUMBER"],
                 ucc=os.environ["NEO_UCC"], totp=totp)
    c.totp_validate(mpin=os.environ["NEO_MPIN"])
    segment = "nse_cm" if alert.segment == "EQUITY" else "nse_fo"
    product = "CNC" if alert.segment == "EQUITY" else "NRML"
    # Always use limit orders; do not silently convert an alert into a market order.
    result = c.place_order(
        exchange_segment=segment, product=product, price=str(alert.price),
        order_type="L", quantity=str(alert.quantity), validity="DAY",
        trading_symbol=alert.symbol, transaction_type="B" if alert.side == "BUY" else "S",
        amo="NO", disclosed_quantity="0", market_protection="0", tag=alert.alert_id[:20]
    )
    return result
