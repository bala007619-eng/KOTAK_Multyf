"""Simulation-first alert receiver. No broker order endpoint exists by design."""
from __future__ import annotations
import hashlib, json, os, re, sqlite3, time
from datetime import date
from pathlib import Path
from typing import Literal, Optional
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field, field_validator

DB_PATH = os.getenv('DB_PATH', './trading.db')
API_KEY = os.getenv('API_KEY', 'change-me')
CAPITAL = float(os.getenv('CAPITAL_BUDGET', '20000'))
DAILY_LIMIT = float(os.getenv('MAX_DAILY_LOSS', '1000'))
MAX_ORDER = float(os.getenv('MAX_ORDER_VALUE', '20000'))
MODE = os.getenv('TRADING_MODE', 'simulation').lower()
if MODE != 'simulation':
    raise RuntimeError('This starter supports simulation mode only; live execution is not implemented.')
app = FastAPI(title='Multyfi Kotak Simulation Gateway', version='0.1.0')

class Alert(BaseModel):
    alert_id: str = Field(min_length=1, max_length=128)
    raw: str = Field(min_length=1, max_length=8000)
    symbol: str = Field(min_length=1, max_length=80)
    side: Literal['BUY','SELL']
    segment: Literal['EQUITY','FUTURES','OPTIONS']
    exchange: Literal['NSE','NFO']
    price: float = Field(gt=0, allow_inf_nan=False)
    quantity: int = Field(gt=0, le=1000000)
    stop_loss: Optional[float] = Field(default=None, gt=0)
    target: Optional[float] = Field(default=None, gt=0)
    product: Literal['MIS'] = 'MIS'

    @field_validator('symbol')
    @classmethod
    def normalize_symbol(cls, v):
        v=v.strip().upper()
        if not re.fullmatch(r'[A-Z0-9._-]{1,80}', v): raise ValueError('Invalid symbol')
        return v

def db():
    con=sqlite3.connect(DB_PATH)
    con.row_factory=sqlite3.Row
    con.execute('''CREATE TABLE IF NOT EXISTS alerts (
      alert_id TEXT PRIMARY KEY, payload TEXT NOT NULL, status TEXT NOT NULL,
      created_at INTEGER NOT NULL, simulated_value REAL NOT NULL, note TEXT NOT NULL)''')
    con.execute('''CREATE TABLE IF NOT EXISTS state (k TEXT PRIMARY KEY, v TEXT NOT NULL)''')
    con.execute("INSERT OR IGNORE INTO state(k,v) VALUES('kill_switch','off')")
    con.commit(); return con

def auth(key):
    if not key or not hashlib.sha256(key.encode()).digest()==hashlib.sha256(API_KEY.encode()).digest():
        raise HTTPException(401,'Invalid API key')

@app.get('/health')
def health(): return {'ok':True,'mode':'simulation','live_orders_enabled':False}

@app.get('/status')
def status(x_api_key: str|None=Header(default=None)):
    auth(x_api_key)
    con=db(); kill=con.execute("SELECT v FROM state WHERE k='kill_switch'").fetchone()['v']
    rows=con.execute('SELECT status, COUNT(*) n FROM alerts GROUP BY status').fetchall(); con.close()
    return {'mode':'simulation','live_orders_enabled':False,'kill_switch':kill,'counts':{r['status']:r['n'] for r in rows},'capital_budget':CAPITAL,'max_daily_loss':DAILY_LIMIT}

@app.post('/alerts')
def receive(a: Alert, x_api_key: str|None=Header(default=None)):
    auth(x_api_key)
    con=db()
    if con.execute("SELECT v FROM state WHERE k='kill_switch'").fetchone()['v']=='on':
        con.close(); raise HTTPException(423,'Kill switch enabled')
    if a.segment=='EQUITY' and a.exchange!='NSE': con.close(); raise HTTPException(422,'Equity must use NSE')
    if a.segment in ('FUTURES','OPTIONS') and a.exchange!='NFO': con.close(); raise HTTPException(422,'F&O must use NFO')
    value=a.price*a.quantity
    if value>MAX_ORDER: con.close(); raise HTTPException(422,'Order value exceeds configured cap')
    if value>CAPITAL: con.close(); raise HTTPException(422,'Order value exceeds capital budget; margin/leverage is not assumed')
    if a.stop_loss is None: note='No stop-loss supplied; accepted in simulation with elevated risk warning.'
    else: note='Stop-loss recorded; simulation does not guarantee execution or protection.'
    try:
        con.execute('INSERT INTO alerts VALUES(?,?,?,?,?,?)',(a.alert_id,a.model_dump_json(),'SIMULATED',int(time.time()),value,note)); con.commit()
    except sqlite3.IntegrityError:
        con.close(); raise HTTPException(409,'Duplicate alert_id; no second simulated order created')
    con.close()
    return {'alert_id':a.alert_id,'status':'SIMULATED','simulated_value':value,'mode':'simulation','live_order_sent':False,'note':note}

@app.post('/kill-switch')
def kill_switch(enabled: bool, x_api_key: str|None=Header(default=None)):
    auth(x_api_key); con=db(); con.execute("UPDATE state SET v=? WHERE k='kill_switch'",('on' if enabled else 'off',)); con.commit(); con.close()
    return {'kill_switch':'on' if enabled else 'off','live_order_sent':False}

@app.get('/alerts')
def list_alerts(x_api_key: str|None=Header(default=None)):
    auth(x_api_key); con=db(); rows=con.execute('SELECT alert_id,payload,status,created_at,simulated_value,note FROM alerts ORDER BY created_at DESC LIMIT 200').fetchall(); con.close()
    return [dict(r) for r in rows]
