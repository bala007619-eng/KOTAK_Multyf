# Kotak Neo live integration source

This package adds a Kotak Neo SDK adapter (`live_gateway.py`) using the official
`neo-api-client` 3.x SDK. It uses limit orders, NSE cash for equity and NSE F&O
for futures/options, with CNC for equity and NRML for derivatives.

**This is integration source, not a finished live-trading system or APK.**
The adapter is not wired into the existing simulation-only `/alerts` endpoint.
Do not enable live orders until all items below are implemented and tested.

Required before live use:
- Wire the adapter into the backend with a persistent order-intent state machine.
- Resolve each Multyfi alert to a valid Kotak trading symbol and verify lot size,
  tick size, expiry, option type and instrument token against the current scrip master.
- Add broker order-book/position reconciliation. Never retry a placement after a
  timeout until its broker status is reconciled.
- Implement daily realized + unrealized P&L monitoring from broker positions and
  enforce the ₹1,000 loss limit server-side; stop entries and define square-off
  behavior explicitly.
- Add a server-side kill switch, account/segment allowlist, max open positions,
  exposure checks and alert age checks.
- Implement authenticated Android-to-server HTTPS forwarding and a user-visible
  connection/configuration screen.
- Verify API IP whitelisting and complete a broker-approved test procedure.
- Build, sign and install the APK; test with paper/sandbox or controlled low-risk
  orders before enabling unattended live trading.

Never place API secrets, MPIN, TOTP, or private keys in the Android APK or chat.
`LIVE_TRADING_ENABLED` defaults to false. Do not set it true on this incomplete
starter. Trading can lose more than a configured daily limit due to gaps, slippage,
rejections, partial fills, and connectivity failures.
