import os, tempfile
from fastapi.testclient import TestClient
os.environ['API_KEY']='test-secret'; os.environ['DB_PATH']=tempfile.mktemp(suffix='.db')
from app import app
client=TestClient(app); H={'x-api-key':'test-secret'}
def alert(**kw):
 d={'alert_id':'a1','raw':'BUY ABC @ 100','symbol':'ABC','side':'BUY','segment':'EQUITY','exchange':'NSE','price':100,'quantity':10}
 d.update(kw); return d
def test_health_is_simulation_only():
 r=client.get('/health'); assert r.status_code==200 and r.json()['live_orders_enabled'] is False
def test_valid_alert_simulates_only():
 r=client.post('/alerts',json=alert(),headers=H); assert r.status_code==200 and r.json()['status']=='SIMULATED' and not r.json()['live_order_sent']
def test_duplicate_rejected():
 r=client.post('/alerts',json=alert(),headers=H); assert r.status_code==409
def test_stop_switch_blocks():
 client.post('/kill-switch?enabled=true',headers=H)
 r=client.post('/alerts',json=alert(alert_id='a2'),headers=H); assert r.status_code==423
